
<div class="slider-area">
    <div class="slider-active">
        <div class="single-slide text-center d-flex align-items-center justify-content-center" style="background-image:url('<?php echo base_url();?>assets/img/image11.jpg');">
          <div class="slider-inner">
            <h2>EPI Reminder</h2>
            <p>Boost your child immune system!!!</p>
            <a  class="btn" href="#">Sign Up</a>
          </div>
        </div>

        <div class="single-slide text-center d-flex align-items-center justify-content-center" style="background-image:url('<?php echo base_url();?>assets/img/kid14.jpg');">
          <div class="slider-inner">
            <h2>EPI Reminder</h2>
            <p>Boost your child immune system!!!</p>
            <a  class="btn" href="#">Sign Up</a>
          </div>
        </div>

        <div class="single-slide text-center d-flex align-items-center justify-content-center" style="background-image:url('<?php echo base_url();?>assets/img/kid15.jpg');">
          <div class="slider-inner">
            <h2>EPI Reminder</h2>
            <p>Boost your child immune system!!!</p>
            <a  class="btn" href="#">Sign Up</a>
          </div>
        </div>
    </div>
</div>

